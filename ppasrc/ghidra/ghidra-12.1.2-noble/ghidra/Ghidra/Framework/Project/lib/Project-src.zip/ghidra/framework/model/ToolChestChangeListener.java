/* ###
 * IP: GHIDRA
 * REVIEWED: YES
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ghidra.framework.model;

/**
 * Listener that is notified when a ToolTemplate is added or removed from a
 * project
 */
public interface ToolChestChangeListener {

    /**
     * ToolConfig was added to the project toolchest
     */
    public void toolTemplateAdded(ToolTemplate tool);

    /**
     * ToolSet was added to the project toolchest
     */
    public void toolSetAdded(ToolSet toolset);

    /**
     * ToolConfig was removed from the project toolchest
     */
    public void toolRemoved(String toolName);
}
