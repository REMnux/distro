/* ###
 * IP: GHIDRA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package agent.frida.model.iface2;

import agent.frida.manager.*;
import agent.frida.model.iface1.FridaModelTargetEventScope;

public interface FridaModelTargetThreadContainer extends //
		FridaModelTargetEventScope, //
		FridaEventsListenerAdapter {

	public FridaModelTargetThread getTargetThread(FridaThread thread);

	public void threadCreated(FridaThread thread, FridaCause cause);

	public void threadReplaced(FridaThread thread, FridaCause cause);

	public void threadExited(FridaThread thread, FridaCause caus);

}
