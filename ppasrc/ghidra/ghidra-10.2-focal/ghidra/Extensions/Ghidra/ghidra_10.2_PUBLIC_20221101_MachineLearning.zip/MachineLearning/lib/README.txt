The "lib" directory is intended to hold Jar files which this contrib
is dependent upon.  This directory may be eliminated from a specific
contrib if no other Jar files are needed.
